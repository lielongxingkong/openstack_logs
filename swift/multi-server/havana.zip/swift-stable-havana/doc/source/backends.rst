======================================
Pluggable Back-ends: API Documentation
======================================

.. automodule:: swift.account.backend
    :private-members:
    :members:
    :undoc-members:

.. automodule:: swift.container.backend
    :private-members:
    :members:
    :undoc-members:

.. automodule:: swift.obj.diskfile
    :members:
